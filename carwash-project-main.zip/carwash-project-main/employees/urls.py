from django.urls import path

app_name = "employees"

urlpatterns = [
    # Пока оставим пустым, можно добавить позже
]
