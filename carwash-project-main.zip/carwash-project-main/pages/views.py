from django.shortcuts import render
from django.views.generic import TemplateView


class AboutView(TemplateView):
    template_name = "pages/about.html"


class ContactView(TemplateView):
    template_name = "pages/contact.html"


class PriceListView(TemplateView):
    template_name = "pages/price_list.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        from services.models import Service, ServiceCategory

        context["categories"] = ServiceCategory.objects.all()
        context["services"] = Service.objects.filter(is_active=True)
        return context


def csrf_failure(request, reason=""):
    return render(request, "pages/403csrf.html", status=403)


def permission_denied(request, exception):
    return render(request, "pages/403csrf.html", status=403)


def page_not_found(request, exception):
    return render(request, "pages/404.html", status=404)


def server_error(request):
    return render(request, "pages/500.html", status=500)
